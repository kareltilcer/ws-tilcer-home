# home — notes

Decisions, interview answers, and open questions. Detailed spec in `PRD.md` + `openapi.yaml`.

## Interview answers (2026-07-19)

- **Logging architecture:** in-app **spine**, extractable. A first-class Go package + its own SQLite tables inside the `home` DB; every module writes through it, in the **same transaction** as the change. Kept behind an `AuditSink` interface so it can be pulled into a standalone logging service later — only when a *second* service needs to log. Not a separate service in v1.
- **Users:** **household** (multiple people). Shared boards; accountability via the audit log's actor rather than a per-card assignee (no assignee field in v1).
- **Auth:** **Mode A** (auth-hosted login). Site key `home`, single_site accounts. Backend verifies JWTs via auth `/introspect` as a `home` service client.
- **Log detail:** **hybrid** — every action → an event; **key entities also record field-level before/after diffs** (`card`, `column`, `board`, `label`, `checklist_item`).
- **To-do model:** "folder" = **column**. Many columns, **sortable** (priority + manual order) and **collapsible**, feeding a **"Working on now"** column, plus a **Done/archive** column. Cards carry **notes, links, checklists, labels** (no due dates, no assignee in v1).

## Key design points

- **Two log planes:** operational request logs → stdout (Coolify); domain audit events → the spine's DB tables → log-browser frontend. Request id links them.
- **Atomicity guarantees completeness:** if the audit write fails, the whole mutation rolls back; if the mutation rolls back, no event is left. This is why the spine is in-process + same-DB.
- **Append-only audit:** no update/delete API for events; optional prune (default: keep forever) self-logs. Full old/new values in diffs; FTS5 for free-text search.
- **Mobile UX:** vertical accordion of collapsible columns with `now` columns pinned; one-tap "Move to…"; desktop is horizontal kanban with drag reorder. Collapse state is client-side (localStorage).
- **Ordering:** lexorank-style string position keys so reorder/move don't rewrite siblings.
- **Real-time:** authenticated `/ws` websocket pushes board/column/card changes; refetch-on-focus is the reconnect fallback.

## Resolved decisions (2026-07-19 — see PRD §10)

- **D1** multiple boards + switcher
- **D2** JWT verify via auth `/introspect` (home service client) + short-TTL cache; secret not distributed
- **D3** column collapse client-side (localStorage), per device — no table/endpoint
- **D4** lexorank string ordering
- **D5** roles = auth default `admin`/`editor`/`reader` (admin=+logs+structural, editor=to-do writes, reader=view-only); logs admin-only
- **D6** full old/new diff values for `card`/`column`/`board`/`label`/`checklist_item`; FTS5 for log search from the start
- **D7** `now`/`done` `kind` is a free-form, non-unique hint
- **D8** card delete soft by default + `?hard=true`
- **D9** no automated/system jobs in v1 (spine still supports them)
- **D10** websockets for live updates

## Pre-implementation setup (after approval)

- **Design pass first:** `HANDOFF-design.md` briefs Claude Design (design system + hi-fi prototype, both breakpoints, Tailwind + shadcn/ui). The Claude Code handoff (`HANDOFF.md`) is written against the PRD *and* the approved design.
- Register `home` site in auth with roles **`admin`/`editor`/`reader`** and provision a `home` **service client** (bound to site `home`) → `HOME_AUTH_SERVICE_SECRET`.
- Coolify env per PRD §9; Litestream → R2 prefix `home/`.
- New repo (TBD).
