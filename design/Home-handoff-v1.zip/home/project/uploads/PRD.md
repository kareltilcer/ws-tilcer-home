# PRD — Home

> Status: **Draft** — open questions resolved 2026-07-19 (see §10); pending Karel's final approval. · Owner: Karel · Last updated: 2026-07-19
> Companion spec: `openapi.yaml` (OpenAPI 3.1, v0.1.0) · Notes: `notes.md`

> **v1 scope:** a single `home` fe/be pair that will grow into a household management system. Two modules ship in v1: (1) a **logging spine** — an in-process audit component every module writes through, plus a detailed log-browser frontend; and (2) a **to-do system** — a Trello-style board of many sortable, collapsible columns feeding a "Working on now" column and an archive, with cards carrying notes, links, checklists, and labels. Everything is built around the logging spine so that future modules inherit auditability for free.

## 1. Overview

- **One-line summary:** A mobile- and desktop-friendly household management system whose modules all write through a central audit-logging spine; v1 delivers that spine (with a rich log browser) and a Trello-style to-do system.
- **Type:** fe/be pair. React + TS + TanStack Query SPA over a Go + embedded-SQLite backend.
- **Subdomain:** `home.tilcer.cz`.
- **Exposure:** **public** (routed via Coolify), gated by auth. The system is used from phones and laptops on and off the home network, so it must be reachable publicly and protected by the shared auth service — never open.
- **Consumers:**
  - **Household members** (browser, mobile + desktop) — the primary users; they run the to-do board.
  - **Admins** (household member with the `admin` role) — additionally browse the audit log.
  - No other service consumes `home` in v1. (If the logging spine is later extracted into a standalone service, *other* backends become consumers — see §Architecture and §10.)
- **Depends on:**
  - **auth** (`auth.tilcer.cz`), site key **`home`**, **Mode A (auth-hosted login)**. Home holds only site-scoped JWTs; the backend verifies them via auth's `POST /introspect` as an auth **service client** bound to site `home`. No other internal dependency.

### Architecture — the logging spine (decision, see §10 D1)

The logging module is implemented as a **first-class, in-process Go package** with its **own dedicated SQLite tables in the home database** — the internal "spine" that every other module writes through. It is **not** a separate service in v1.

- **Same-transaction writes.** A module records an audit event **inside the same SQLite transaction** as the change it describes. The event and the change commit or roll back together, which *guarantees* no successful action goes unlogged and no logged action was rolled back. This atomicity is the reason the spine lives in-process and in the same DB.
- **Extraction seam.** Modules call the spine through a narrow `AuditSink` interface (record an event + its field changes). v1 ships one implementation: an in-process writer to the home DB. If a *separate* service later needs to log here, we add a second implementation — a BE→BE HTTP client — and stand up a `POST /internal/logs` ingest endpoint on a (possibly extracted) logging service, provisioned with its own auth service client. Nothing in module code changes. We do **not** build the ingest endpoint or extract the service until a second service actually needs it (YAGNI).
- **Two log planes, kept separate.** *Operational* request logs (method, path, status, latency, request id) go to **stdout** as structured JSON for Coolify to capture (the project baseline). *Domain* audit events (who did what to which entity, with field diffs) go to the **logging spine's DB tables** and are queryable through the log-browser frontend. These are different concerns and different stores.

## 2. Goals & Non-Goals

**Goals**

- Ship a logging spine that captures **every mutating action across every module** (itself included) as a queryable audit event, written atomically with the change.
- Use the **hybrid** log model (see §5): every action produces an event; **key entities also record field-level before/after diffs**.
- Give admins a **detailed log browser**: filter by time, module, actor, action, entity, and level; free-text search; per-entity timeline (full history of one card/column/board); and simple analytics (counts by dimension over time).
- Ship a **Trello-style to-do system** that is genuinely pleasant on both mobile and desktop: many columns that can be **collapsed** and **sorted by priority**, a **"Working on now"** column, and an **archive**; cards with **notes, links, checklists, and labels**.
- Make **most common actions reachable in one or two taps/clicks** from either form factor.
- Support a **household**: multiple people share the same boards; every change is attributed to its actor via the spine.
- Be a clean second consumer of **auth** (Mode A) and a faithful implementation of the project conventions (observability, Goose, Litestream→R2, OpenAPI 3.1).

**Non-Goals (v1)**

- **No card assignee field** — the household shares boards, and accountability comes from the audit log's actor, not per-card assignment. (Assignee is a likely v2 addition.)
- **No due dates / reminders / notifications** in v1.
- **No collaborative editing** (live cursors, simultaneous co-editing of the same card text via OT/CRDT). v1 *does* push board/column/card **changes** over a websocket (§10 D10) so devices stay in sync — but concurrent edits to the same field are last-write-wins, not merged.
- **No separate logging microservice / BE→BE ingest endpoint** in v1 (the spine is in-process; only the extraction seam is built).
- **No retention/rotation policy tuning** beyond an optional prune switch (default: keep forever).
- **No offline / PWA install**, no native apps. Responsive web only.
- **No cross-board card moves**, no card templates, no automations/rules (Butler-style) in v1.

## 3. Users & Roles

Home is a consumer **site** (`home`) of the shared auth service. Household members are **`single_site`** accounts bound to the `home` site (their email is unique within `home`; the same address could exist independently on another site). Access uses **Mode A**: the frontend redirects unauthenticated users to `auth.tilcer.cz` to log in; auth owns the login UI, session cookie, and token refresh; home only ever holds a site-scoped JWT.

**Roles on the `home` site** — reuse auth's **default template `admin` / `editor` / `reader`** (§10 D5), mapped as:

- **`admin`** — full access, including the **log browser** and structural management (create/delete boards, columns, labels). (Household lead.)
- **`editor`** — full **to-do** use: create/move/edit a board's contents — columns, cards, checklists, links, labels. No log browser.
- **`reader`** — **view-only**: read boards, columns, and cards; no mutations, no log browser.

Authorization is carried in the site-scoped JWT `roles` claim (per the auth model; superuser tokens present `roles:["*"]` and are treated as full access). Home authorizes each request from the verified claims:

- To-do **reads** (`GET` on `/api/boards/**`, `/api/columns/**`, `/api/cards/**`, `/api/labels/**`): any authenticated `home` user (`reader`, `editor`, or `admin`).
- To-do **writes** (`POST`/`PATCH`/`DELETE`/move on the same): **`editor` or `admin`**.
- Log-browser endpoints (`/api/logs/**`): **`admin` only**.
- Health probes: public.

## 4. Functional Requirements

Requirements are grouped by module. **Every mutating to-do requirement (FR-T\*) records an audit event through the logging spine in the same transaction** — this is stated once here and not repeated per FR. Reads are **not** logged (they would swamp the log and create read-amplification); only mutations and explicit administrative actions are.

### Logging module

#### FR-L1: Record an audit event (spine, internal)
- **Description:** The internal API every module calls to record one audit event.
- **Trigger:** Any module mutation (user- or system-initiated). Not exposed over HTTP in v1.
- **Inputs:** `actor` (user id + type `user|system|service`, or the resolved system/service label for automated actions), `module` (e.g. `todo`, `logging`), `action` (dotted verb, e.g. `card.create`, `card.move`, `column.reorder`), `entity_type` + `entity_id` (nullable), `summary` (human-readable), `level` (`info|warn|error`, default `info`), and request context (`request_id`, `ip`, `user_agent`, `site`) supplied by middleware. Optional `meta` (JSON) and optional `changes` (see FR-L2).
- **Behaviour:** Insert one `audit_events` row **within the caller's open transaction**. Timestamp is server UTC. Actor/context are read from the request-scoped context populated by auth + logging middleware; automated jobs pass an explicit `system` actor. If the surrounding transaction rolls back, the event is discarded with it.
- **Outputs:** the event id (for correlating child change rows).
- **Errors:** a failure to insert the event **fails the whole transaction** (the action does not silently succeed unlogged).

#### FR-L2: Field-level change capture (hybrid)
- **Description:** For **key entities**, record before/after values per changed field alongside the event.
- **Trigger:** A mutation on a key entity. **Key entities in v1:** `card`, `column`, `board`, `label`, `checklist_item` (§10 D6).
- **Inputs:** a list of `{ field, old, new }` for fields that actually changed (unchanged fields omitted); values serialized as text/JSON.
- **Behaviour:** Insert one `audit_changes` row per changed field, linked to the FR-L1 event, in the same transaction. Creates record `{field, null → new}`; deletes record the final state or a single `deleted` marker (configurable per call). **Full** old/new values are stored, including large text like card notes — no truncation (§10 D6).
- **Outputs:** change rows persisted; visible in the event detail and entity timeline.
- **Errors:** as FR-L1 (atomic with the event and the change).

#### FR-L3: Browse / query events
- **Description:** List audit events with rich filtering for the log browser.
- **Trigger:** Admin opens the Logs view / applies filters.
- **Inputs (query):** `from`, `to` (time range), `module`, `actor` (user id), `action`, `entity_type`, `entity_id`, `level`, `q` (free-text over `summary` + `meta`), plus `limit` and `cursor` (UUIDv7 keyset pagination, newest-first).
- **Behaviour:** Return matching events ordered by `ts` desc (id tiebreak), each with a change **count** (not the full change list — that's fetched per event). Filters compose (AND). Indexed paths for the common filters (§5).
- **Outputs:** `200` paged list `{ items, next_cursor }`.
- **Errors:** `403` non-admin; `422` bad filter/range.

#### FR-L4: Event detail
- **Description:** One event with its full field-change list.
- **Inputs:** event `id`.
- **Outputs:** `200` event + `changes[]`.
- **Errors:** `403`; `404`.

#### FR-L5: Entity timeline (audit trail of one thing)
- **Description:** The complete, ordered history of a single entity — the payoff of the hybrid model. E.g. everything that ever happened to card X, with each field diff.
- **Inputs:** `entity_type`, `entity_id`; optional `from`/`to`, `limit`, `cursor`.
- **Behaviour:** Return all events where `(entity_type, entity_id)` match, oldest-first by default (chronological history), each with its changes.
- **Outputs:** `200` paged timeline.
- **Errors:** `403`; `404` (unknown entity ⇒ empty timeline, not an error, unless the type is unknown).

#### FR-L6: Analytics / aggregations
- **Description:** Simple counts to make the log browsable at a glance.
- **Inputs:** `dimension` (`module|actor|action|level`), `bucket` (`day|week`), `from`, `to`, optional filters as FR-L3.
- **Behaviour:** Return grouped counts (e.g. events per module per day) for charting; and top-N actors/actions for the range.
- **Outputs:** `200` `{ buckets[], totals[] }`.
- **Errors:** `403`; `422`.

#### FR-L7: Retention (append-only + optional prune)
- **Description:** Audit data is **append-only**: no update or delete of events/changes via any API. Optional background prune deletes events older than `HOME_LOG_RETENTION_DAYS` (default `0` = keep forever). A prune run, if it deletes anything, **records its own audit event** (`logging.prune`, `system` actor) — the module logging itself.
- **Errors:** n/a (internal/scheduled).

### To-do module

> Model recap: a **board** contains **many columns**; columns are **sortable** (by priority and/or manual order) and **collapsible**; a designated column acts as **"Working on now"** and another as the **archive/done**. A **card** lives in exactly one column and carries a title, markdown **notes**, structured **links**, a **checklist**, and **labels**. The workflow is: cards wait in their columns, get **moved into "Working on now"** for the period, then **moved to the archive** when done.

#### FR-T1: Boards
- **Description:** CRUD of boards (top-level container). **Multiple boards** are supported in v1, surfaced via a board switcher (§10 D1).
- **Inputs:** `name`, optional `description`.
- **Behaviour:** On first run, seed a default board **"Home"** with three columns — **"Backlog"**, **"Working on now"** (marked `kind=now`), **"Done"** (marked `kind=done`) — if no board exists. List returns boards in manual order.
- **Outputs:** `201`/`200`.
- **Errors:** `403` unauthenticated; `404`; `409` duplicate name (if enforced).

#### FR-T2: Columns — CRUD, priority, sort, collapse
- **Description:** Manage the many columns of a board.
- **Inputs:** `board_id`, `name`, optional `priority` (integer/enum used for sorting), optional `kind` (`normal|now|done`, default `normal`), `position` (manual order).
- **Behaviour:**
  - **Create/rename/delete** columns. Deleting a non-empty column requires either it be empty or `?cascade=true` (cards deleted → each logged); default blocks with `409` + card count.
  - **Reorder** columns via an explicit move (set `position`; lexorank string ordering, §10 D4). Columns can also be **sorted by `priority`** in the UI without changing manual order.
  - **Collapse/expand** is a per-column UI state, stored **client-side** (localStorage) per device — not persisted server-side (§10 D3).
  - `kind` (`normal|now|done`) is a **free-form UI hint**: a board may have any number of `now`/`done` columns. It drives mobile pinning and the done-stamp on card move; nothing is enforced unique (§10 D7).
- **Outputs:** `200`/`201`.
- **Errors:** `403`; `404`; `409` (non-empty delete).

#### FR-T3: Cards — CRUD, move, reorder
- **Description:** The to-do items.
- **Inputs:** `column_id`, `title`, optional `notes` (markdown).
- **Behaviour:**
  - **Create** appends to a column (or at a given position). **Edit** title/notes. **Delete** is **soft** by default (set `archived=true`), with a hard delete behind `?hard=true` (§10 D8).
  - **Move** a card to another column and/or position in one operation (the core workflow action: → "Working on now", → "Done"). Moving into a `kind=done` column stamps `done_at`; moving out clears it.
  - Reordering within a column uses the same ordering scheme as columns.
- **Outputs:** `200`/`201`.
- **Errors:** `403`; `404`; `422` (unknown target column).

#### FR-T4: Card notes & links
- **Description:** Rich content on a card.
- **Behaviour:** `notes` is a markdown text field (rendered read-only in the UI; edited as plain markdown). **Links** are structured rows `{ url, title? }`, ordered, added/removed independently of notes so they can be listed and clicked cleanly on mobile. URLs are validated (scheme allowlist `http`/`https`).
- **Errors:** `422` invalid URL.

#### FR-T5: Checklists (sub-todos)
- **Description:** A single ordered checklist per card.
- **Inputs:** item `text`, `done` flag, `position`.
- **Behaviour:** Add/rename/check/uncheck/delete/reorder items. Card surfaces a progress count (`done/total`). (One checklist per card in v1; named multiple checklists are future.)
- **Errors:** `403`; `404`.

#### FR-T6: Labels / tags
- **Description:** Colored labels for cross-cutting categorization and filtering, independent of column.
- **Inputs:** `name`, `color`; board-scoped.
- **Behaviour:** CRUD labels on a board; attach/detach labels to cards; filter the board by one or more labels. Deleting a label detaches it from all cards (logged).
- **Errors:** `403`; `404`; `409` duplicate name/color per board (if enforced).

#### FR-T7: Board fetch & filtering (read model)
- **Description:** Efficiently load a board for rendering, and filter it.
- **Inputs:** `board_id`; optional filters `label`, `q` (text over card title/notes), `include_archived`.
- **Behaviour:** Return the board **tree** — columns in sort order, each with its cards in order, each card with label ids and checklist progress (not full checklist/links — those load in the card detail). Filtering narrows cards; empty columns still render (so cards can be dropped in). (Collapse is applied client-side, §10 D3.)
- **Outputs:** `200` board tree.
- **Errors:** `403`; `404`.

### Health

#### FR-H1: Health probes
- `GET /healthz` (liveness) and `GET /readyz` (readiness incl. SQLite ping), per the project baseline. Public.

## 5. Data Model

SQLite (embedded), Goose migrations. Timestamps UTC ISO-8601. IDs **UUIDv7** (sortable, keyset-pagination friendly). Ordering fields (`position`) use **lexorank-style string keys** — always insertable between two neighbors, so reorder/move never rewrites siblings and there's no float-precision limit (§10 D4).

### Logging tables (created first — "build everything around it")

**audit_events**
- `id` PK (UUIDv7) · `ts` TIMESTAMP NOT NULL · `actor_user_id` TEXT NULL (NULL for `system`) · `actor_type` TEXT CHECK in (`user`,`system`,`service`) · `actor_label` TEXT NULL (denormalized display, e.g. job name) · `module` TEXT NOT NULL · `action` TEXT NOT NULL · `entity_type` TEXT NULL · `entity_id` TEXT NULL · `summary` TEXT NOT NULL · `level` TEXT CHECK in (`info`,`warn`,`error`) DEFAULT `info` · `request_id` TEXT NULL · `ip` TEXT NULL · `user_agent` TEXT NULL · `site` TEXT NOT NULL DEFAULT `home` · `meta` TEXT NULL (JSON).
- Indexes: `idx_events_ts` (`ts` desc), `idx_events_module_ts` (`module`,`ts`), `idx_events_actor_ts` (`actor_user_id`,`ts`), `idx_events_entity` (`entity_type`,`entity_id`,`ts`), `idx_events_action` (`action`).
- **Free-text search:** a **SQLite FTS5** virtual table (`audit_events_fts`) indexes `summary` + a flattened `meta`, kept in sync with the base table via triggers; the `q` filter queries it (§10 D6).
- **Append-only:** no `UPDATE`/`DELETE` path except FR-L7 prune.

**audit_changes**
- `id` PK (UUIDv7) · `event_id` FK→audit_events ON DELETE CASCADE · `field` TEXT NOT NULL · `old_value` TEXT NULL · `new_value` TEXT NULL. **Full** values stored, no truncation (§10 D6).
- Index: `idx_changes_event` (`event_id`), optional `idx_changes_field` (`field`).

### To-do tables

**boards** — `id` PK · `name` TEXT NOT NULL · `description` TEXT NULL · `position` (order) · `created_by` FK→(auth user id, stored as text) · `created_at` · `archived` BOOL DEFAULT false.

**columns** — `id` PK · `board_id` FK→boards ON DELETE CASCADE · `name` TEXT NOT NULL · `priority` INTEGER NOT NULL DEFAULT 0 · `position` (manual order) · `kind` TEXT CHECK in (`normal`,`now`,`done`) DEFAULT `normal` · `created_at`. Indexes: `(board_id, position)`, `(board_id, priority)`. `kind` is a non-unique hint — no uniqueness constraint (§10 D7).

**cards** — `id` PK · `column_id` FK→columns ON DELETE CASCADE · `title` TEXT NOT NULL · `notes` TEXT NULL (markdown) · `position` · `created_by` · `created_at` · `updated_at` · `done_at` TIMESTAMP NULL · `archived` BOOL DEFAULT false. Index: `(column_id, position)`, `idx_cards_updated` (`updated_at`).

**card_links** — `id` PK · `card_id` FK ON DELETE CASCADE · `url` TEXT NOT NULL · `title` TEXT NULL · `position`. Index `(card_id, position)`.

**checklist_items** — `id` PK · `card_id` FK ON DELETE CASCADE · `text` TEXT NOT NULL · `done` BOOL DEFAULT false · `position`. Index `(card_id, position)`.

**labels** — `id` PK · `board_id` FK ON DELETE CASCADE · `name` TEXT NOT NULL · `color` TEXT NOT NULL · `created_at`. Unique `(board_id, name)`.

**card_labels** — `card_id` FK ON DELETE CASCADE · `label_id` FK ON DELETE CASCADE · PK `(card_id, label_id)`. Index `(label_id)`.

*(No `user_column_state` table — column collapse is client-side/localStorage per §10 D3.)*

**Goose notes:** `0001_init` creates the **logging tables first** (incl. the `audit_events_fts` FTS5 table + sync triggers), then the to-do tables, all indexes and CHECKs, and seeds the default **"Home"** board + `Backlog`/`Working on now`/`Done` columns **only when `boards` is empty** (so a fresh build restored from R2 does not double-seed). Future migrations: card assignee (v2), due dates, multiple checklists.

## 6. API Surface

Full detail in `openapi.yaml`. All application endpoints are under `/api` and require a valid site-scoped **JWT** (`bearerAuth`); log endpoints additionally require the **`admin`** role; health is public. There are **no BE→BE endpoints in v1** (the logging spine is in-process; the `POST /internal/logs` ingest is the documented future extraction seam only).

- **To-do:**
  - `GET/POST /api/boards`, `GET/PATCH/DELETE /api/boards/{id}`, `GET /api/boards/{id}/tree` (FR-T7 read model).
  - `GET/POST /api/boards/{id}/columns`, `PATCH/DELETE /api/columns/{id}`, `POST /api/columns/{id}/move`. *(Collapse is client-side — no endpoint.)*
  - `POST /api/columns/{id}/cards`, `GET/PATCH/DELETE /api/cards/{id}`, `POST /api/cards/{id}/move`.
  - `GET/POST /api/cards/{id}/links`, `DELETE /api/links/{id}`.
  - `GET/POST /api/cards/{id}/checklist`, `PATCH/DELETE /api/checklist/{id}`.
  - `GET/POST /api/boards/{id}/labels`, `PATCH/DELETE /api/labels/{id}`, `POST/DELETE /api/cards/{id}/labels/{labelId}`.
- **Logs (admin):** `GET /api/logs`, `GET /api/logs/{id}`, `GET /api/logs/entity/{type}/{id}`, `GET /api/logs/stats`.
- **Real-time:** `GET /ws` — authenticated **websocket** upgrade; the server pushes board/column/card change events so open boards update live across devices (§10 D10). Not modeled in `openapi.yaml` (which covers HTTP only).
- **Health (public):** `GET /healthz`, `GET /readyz`.

**Auth per endpoint:** `security: []` for health; `bearerAuth` for everything under `/api` and the `/ws` upgrade. To-do **writes** require `editor`/`admin`; `/api/logs/**` require `admin` (checked from JWT `roles` in the handler). The backend verifies JWTs via auth `POST /introspect` (authenticated as the `home` service client) with **short-TTL caching**; the signing secret is never distributed (§10 D2).

**Conventions:** list/log endpoints use `?limit=&cursor=` (UUIDv7 keyset). Board tree returns columns/cards already ordered. Errors use the shared `Error { error, detail }` schema. Mutations are expected to be small and frequent; reorder/move use fractional-index positions to avoid rewriting siblings.

## 7. Frontend

React + TS + TanStack Query SPA, **mobile-first and desktop-friendly**, with a shared app shell: module navigation (To-do, and Logs for admins) as a **bottom tab bar on mobile / side nav on desktop**. Auth is Mode A: an unauthenticated load redirects to `auth.tilcer.cz` (site `home`); a shared fetch wrapper attaches the JWT and, on `401`, calls auth `POST /token/refresh` once (same-site cookie on `tilcer.cz`) and retries, else redirects to login.

**To-do board**

- A lightweight **board switcher** (dropdown / segmented control) selects the active board; multiple boards are supported from v1 (§10 D1).
- **Desktop:** horizontal **kanban** of columns. Columns are **collapsible** (collapse to a thin labeled spine so many columns fit; collapsed state remembered **per device via localStorage**, §10 D3) and **sortable** (drag to reorder, or sort by priority). Drag-and-drop for cards and columns (dnd-kit). "Working on now" column visually emphasized.
- **Mobile:** a **vertical accordion** of collapsible columns rather than a horizontal kanban — friendlier for thumbs. "Working on now" is **pinned to the top**. Reordering and moving cards use an explicit **"Move to…" control** in addition to (finicky) touch drag, so the core action is always one tap → pick target column. Quick-add card at the top of each column.
- **Card detail:** full-screen sheet on mobile, modal on desktop — title, markdown notes (view/edit toggle), links list (add/open/remove), checklist with progress, labels. Every common action (add card, move card, check an item, add a label) is reachable in ≤2 taps from the board.
- **Filtering:** by label chip(s) and text search; toggle show/hide archived/done.

**Logs (admin)**

- **Filter bar:** date range, module, actor, action, entity type/id, level, and free-text `q`.
- **Result stream/table:** newest-first, each row expandable to reveal the field diff (`old → new`) from `audit_changes`.
- **Entity timeline:** from any event (or a card's detail via an "History" affordance) open the full chronological history of that entity.
- **Analytics panel:** small charts of counts by module/actor/action over the selected range (FR-L6), plus top actors/actions.

**Data fetching (TanStack Query):**

- Keys: `['boards']`, `['board', id, 'tree', {filters}]`, `['card', id]`, `['board', id, 'labels']`, `['logs', {filters}]`, `['logs', 'entity', type, id]`, `['logs', 'stats', {params}]`.
- **Optimistic updates** for move/reorder/check with rollback on error; on settle, invalidate `['board', id, 'tree']`.
- **Real-time (§10 D10):** the app opens an authenticated **websocket** (`/ws`); board/column/card change events are pushed and applied to the cached board tree (via `queryClient.setQueryData` / targeted invalidation) so members see each other's edits live. A refetch-on-focus fallback covers reconnects and missed messages.
- Explicit **empty / loading / error** states everywhere.

## 8. Non-Functional Requirements

- **Observability (baseline):** `GET /healthz`, `GET /readyz` (SQLite ping), **structured JSON logs to stdout** (operational plane — captured by Coolify), and a **per-request log** (method, path, status, latency, request id). The request id is propagated into the request context and stamped onto audit events (FR-L1), tying the two planes together.
- **Audit completeness & integrity:** audit writes are **in the same transaction** as the mutation (FR-L1) — an action cannot succeed unlogged, and a rolled-back action leaves no event. Audit tables are **append-only** (no update/delete API; prune is the sole exception and self-logs).
- **Performance:** household scale (a handful of users, thousands of cards, growing audit log). Targets: p95 < 50 ms for board-tree fetch and log queries over indexed filters; keep board-tree payloads small (labels/checklist summarized, details lazy-loaded). Log queries run against an indexed column (time/module/actor/entity/action); free-text `q` runs against the **FTS5** index.
- **Security:** JWT validated via auth `/introspect` (home service client, scoped to site `home`) with **short-TTL caching**; **role gating** enforced server-side from claims, never trusted from the client (`editor`/`admin` for to-do writes, `admin` for logs); the **websocket** (`/ws`) authenticates on connect with the same JWT and is role-authorized (and drops when the token can't be refreshed); input validation on every write (URL scheme allowlist for links, length caps on titles/summaries); all secrets via **Coolify env**, none in the repo; HTTPS/WSS via Coolify. CORS: same-site under `tilcer.cz`; FE uses the shared refresh flow.
- **Backup:** **Litestream → Cloudflare R2**, prefix **`home/`** (one prefix per DB). Fresh build **restores from R2 before serving**; seed logic (default board) runs **only if empty after restore**.

## 9. Configuration

Env vars (values live in Coolify; nothing secret in the repo):

- `HOME_DB_PATH` — SQLite file path (persisted volume).
- `HOME_SITE_KEY` — auth site key (default `home`).
- `AUTH_BASE_URL` — `https://auth.tilcer.cz` (login redirect target, `/introspect`, `/token/refresh`).
- `HOME_AUTH_SERVICE_SECRET` — this service's **auth service-client** secret (bound to site `home`) used to call `POST /introspect` (results cached for the token TTL). *(Local HS256 verify was considered and rejected — §10 D2.)*
- `HOME_ALLOWED_ORIGINS` — CORS allowlist (`https://*.tilcer.cz`) if cross-subdomain fetches are needed.
- `HOME_LOG_RETENTION_DAYS` — audit prune threshold; default `0` = keep forever.
- `LITESTREAM_*` / R2 credentials — backup to prefix `home/`.

## 10. Resolved Decisions

All open questions were resolved with Karel on 2026-07-19:

- **D1 — Boards:** **multiple boards** in v1, with a lightweight **board switcher** in the UI (schema already supports many; §3/§7).
- **D2 — JWT verification:** verify via auth **`POST /introspect`** as the `home` service client, with **short-TTL caching**. The signing secret is **not** distributed to home (local HS256 verify rejected).
- **D3 — Collapse state:** column collapse is **client-side (localStorage)**, per device. No server table, no endpoint.
- **D4 — Ordering scheme:** **lexorank-style string keys** for `position` (columns and cards) — always insertable between neighbors, no sibling rewrites, no float-precision limit.
- **D5 — Home roles:** reuse auth's **default `admin` / `editor` / `reader`** template. `admin` = full + log browser + structural; `editor` = full to-do writes; `reader` = view-only. Log browser is **`admin`-only** (§3).
- **D6 — Diffs & search:** key-entity field diffs for `card`, `column`, `board`, `label`, `checklist_item`, storing **full** old/new values (no truncation). Log free-text `q` is served by a **SQLite FTS5** index from the start.
- **D7 — `now`/`done` columns:** `kind` is a **free-form UI hint** — any number allowed per board; no uniqueness enforced. It drives mobile pinning and the `done_at` stamp.
- **D8 — Card deletion:** **soft** by default (`archived=true`), hard delete behind `?hard=true`.
- **D9 — Automated actions:** **none in v1**. The logging spine still supports `system`-actor events for future jobs.
- **D10 — Real-time:** **websockets** — an authenticated `/ws` channel pushes board/column/card changes so devices update live; refetch-on-focus is the reconnect fallback.

## 11. Acceptance Criteria

- [ ] PRD + `openapi.yaml` reviewed and approved; decisions (§10) locked.
- [ ] `home` site registered in **auth** with roles **`admin`/`editor`/`reader`**; a `home` **service client** provisioned (bound to site `home`) for `/introspect` (cached); Mode A login redirect + refresh loop working end-to-end.
- [ ] Goose `0001_init` creates the **logging tables first** (incl. the **FTS5** table + sync triggers), then to-do tables, with all indexes/CHECKs; seeds the default **Home** board + `Backlog`/`Working on now`/`Done` columns **only when empty**.
- [ ] **Logging spine:** every to-do mutation writes an `audit_events` row **in the same transaction**; a forced rollback leaves **no** event; a forced event-insert failure rolls back the mutation.
- [ ] **Hybrid diffs:** mutations on key entities also write `audit_changes` rows storing **full** old/new values; event detail and entity timeline show `old → new`.
- [ ] **Log browser:** filter by time/module/actor/action/entity/level + **FTS5** free-text; per-entity timeline; analytics counts by dimension; **non-admin gets `403`** on all `/api/logs/**`.
- [ ] **Role gating:** `reader` gets `403` on all to-do mutations; `editor`/`admin` succeed; only `admin` reaches `/api/logs/**`.
- [ ] **To-do:** **multiple boards** + switcher; boards/columns/cards CRUD; columns **reorder + priority-sort** (lexorank) + **collapse (client-side)**; cards **move between columns** (→ Working on now, → a `done` column stamps `done_at`); notes (markdown), links (validated), checklist (progress), labels (attach/detach/filter).
- [ ] **Board tree** endpoint returns ordered columns + cards (with label ids + checklist progress); label and text filters work.
- [ ] **Real-time:** an authenticated `/ws` pushes board/column/card changes; two devices on the same board see each other's edits live; reconnect falls back to refetch-on-focus.
- [ ] **Mobile UX:** vertical collapsible-column accordion with **`now` columns pinned**, one-tap **"Move to…"**, ≤2-tap common actions; **desktop** horizontal kanban with drag reorder. Both verified on real viewport sizes.
- [ ] Baseline observability present; operational request logs on stdout carry a request id that appears on audit events.
- [ ] **Litestream→R2 (`home/`)** configured; fresh-build **restore** verified; seed does not double-run after restore.
- [ ] Service registered in `REGISTRY.md`.
